document.addEventListener("DOMContentLoaded", () => {
  const body = document.body;
  const themeToggle = document.getElementById("toggleTheme");

  // Toggle Dark/Light Mode
  themeToggle.addEventListener("click", () => {
      body.classList.toggle("light");
      body.classList.toggle("dark");
  });
});

// Function to open book document
function openBook(bookFile) {
  window.open(bookFile, "_blank"); // Open book in a new tab
}
