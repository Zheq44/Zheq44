document.addEventListener("DOMContentLoaded", () => {
    const loginContainer = document.getElementById("loginContainer");
    const signupContainer = document.getElementById("signupContainer");
    const toggleSignupButton = document.getElementById("toggleSignup");

    const loginForm = document.getElementById("loginForm");
    const signupForm = document.getElementById("signupForm");
    const loginErrorMessage = document.getElementById("loginErrorMessage");
    const signupErrorMessage = document.getElementById("signupErrorMessage");

    // Store registered users
    const registeredUsers = {};

    // Toggle Signup Form Visibility
    toggleSignupButton.addEventListener("click", () => {
        signupContainer.classList.toggle("hidden");
        loginContainer.classList.toggle("hidden");
    });

    // Handle Login Submission
    loginForm.addEventListener("submit", (event) => {
        event.preventDefault();
        const username = document.getElementById("loginUsername").value;
        const password = document.getElementById("loginPassword").value;

        if (registeredUsers[username] && registeredUsers[username] === password) {
            alert("Login successful! Redirecting to the Library System...");
            // Redirect to main library management page (to be implemented)
            window.location.href = "lib.html"; // Adjust the path as needed
        } else {
            loginErrorMessage.textContent = "Invalid username or password.";
        }
    });

    // Handle Signup Submission
    signupForm.addEventListener("submit", (event) => {
        event.preventDefault();
        const username = document.getElementById("signupUsername").value;
        const password = document.getElementById("signupPassword").value;

        if (registeredUsers[username]) {
            signupErrorMessage.textContent = "Username already exists. Please choose another.";
        } else {
            registeredUsers[username] = password; // Store new user credentials
            alert("Sign up successful! You can now log in.");
            signupForm.reset();
            signupContainer.classList.add("hidden");
            loginContainer.classList.remove("hidden");
        }
    });
});
